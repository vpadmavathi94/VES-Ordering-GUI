import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, Component }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

@Component({
    selector: 'my-app',
    template: `<input type='text' placeholder= "Enter stock symbol" 
       [(ngModel)] = "lastStockSymbol" />
               <br>The value of lastStockSymbol is {{lastStockSymbol}}`
})
class StockComponent {

    lastStockSymbol: string;

    constructor() {
        setTimeout(() => {
            // Code to get the last entered stock from
            // local history goes here (not implemented)

            this.lastStockSymbol="Microsoft";
        }, 2000);
    }
}
@Component({
    selector: 'my-app',    
    template:`<h2>{{lastStockSymbol}}</h2>`

})
class AppComponent {}

@NgModule({
    imports:      [ BrowserModule, FormsModule],
    declarations: [ StockComponent],
    bootstrap:    [ StockComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);
