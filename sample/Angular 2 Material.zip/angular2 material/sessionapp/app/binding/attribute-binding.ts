import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, Component }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'my-app',
  template: `
    <h3>Property vs attribute binding:</h3>
    <input [value]="greeting" [attr.value] = "greeting" 
    (input)="onInputEvent($event)"> <div>{{greeting}}</div>
  `
})
class AttributeBindingComponent {

  greeting: string = 'Murthy';
    //observe in elements section in debugger
    
  onInputEvent(event: Event): void {
    let inputElement: HTMLInputElement = <HTMLInputElement> event.target;

    console.log(`The input property value after change = ${inputElement.value}`);//Murthyg
    console.log(`The input attribute value = ${inputElement.getAttribute('value')}`);//Murthy
    console.log(`The greeting property value = ${this.greeting}`); //Murthy
  }
}

@NgModule({
  imports:      [ BrowserModule],
  declarations: [ AttributeBindingComponent],
  bootstrap:    [ AttributeBindingComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);









/*

// Using destructuring

onInputEvent({target}): void {

  console.log(`The input property value = ${target.value}`);
console.log(`The input attribute value = ${target.getAttribute('value')}`);
console.log(`The greeting property value = ${this.greeting}`);
}
}
*/