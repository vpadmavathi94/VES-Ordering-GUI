import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, Component }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

@Component({
    selector: 'my-app',
    template: `
      
           <h4>Click your favorite drink:<br>
              <span *ngFor="let item of Items" 
              style="background-color:orange;margin-left:40px" 
                (click)="onItemClicked(item)">
                  {{ item.name }} <br/>
              </span>
              <br/>
    You have selected : <input type="text" [(ngModel)]="clickedItem.name">
     </h4>
       
   `
})
class SimpleBindingComponent {
     public Items = [
                     {name: "Butter"},
                     {name: "Milk"},
                     {name: "Yogurt"},
                     {name: "Cheese"},
                  ];
     public clickedItem:any = {name: ""};
     onItemClicked(Item:string) {
        this.clickedItem = Item;
     }
}


@NgModule({
    imports:      [ BrowserModule,FormsModule],
    declarations: [ SimpleBindingComponent],
    bootstrap:    [ SimpleBindingComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);