import {Component} from '@angular/core';
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

// Component
@Component({
  selector: 'my-app',
  template: '<h1>Welcome to  {{ name }}!</h1>'
})

class HelloWorldComponent {
  name: string;

  constructor() {
    this.name = 'Angular 2.0 by Murthy';
  }
}

// Module
@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ HelloWorldComponent ],
  bootstrap:    [ HelloWorldComponent ]
})

export class AppModule { }

// App bootstrap
platformBrowserDynamic().bootstrapModule(AppModule);