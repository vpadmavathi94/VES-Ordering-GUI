import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, Component }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import {ProductService, Product} from "./product-service";

@Component({
  selector: 'my-app',
  template: `<div>
  <h1>Product Details</h1>
  <h2>Title: {{product.title}}</h2>
  <h2>Description: {{product.description}}</h2>
  <h2>Price: \${{product.price}}</h2>
</div>`,
  providers:[ProductService]
})

export  class ProductComponent {
  product: Product;

  constructor( productService: ProductService) {

    this.product = productService.getProduct();
  }
}

@NgModule({
    imports:      [ BrowserModule],
    declarations: [ ProductComponent],
    bootstrap:    [ ProductComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);

