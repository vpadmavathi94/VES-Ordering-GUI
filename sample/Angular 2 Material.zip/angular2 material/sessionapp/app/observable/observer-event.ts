/*
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, Component }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormControl,  ReactiveFormsModule} from '@angular/forms';
//import 'rxjs/Rx'; // import all operators
import 'rxjs/add/operator/debounceTime';  //map,switchmap....

@Component({
    selector: "my-app",
    template: `
       <h2 class='container'>Observable events
       <h2 class="text-success">Enter Company :</h2>
        <input type="text" placeholder="Enter company" 
        [formControl]="searchInput">      
        </h2>      
      <h2 class="text-danger container">{{info}}</h2>
    `
})
class ObserverComponent {
    info:string='';
    searchInput: FormControl = new FormControl('');

    constructor(){
        this.searchInput.valueChanges
            .debounceTime(500)
            .subscribe(
              (stock:string) => this.getStockQuoteFromServer(stock));
    }

    getStockQuoteFromServer(stock: string) {
         // get Actual stock price from server 
         this.info=`The price of ${stock} is ${100*Math.random().toFixed(4)}`
        console.log(`The price of ${stock} is ${100*Math.random().toFixed(4)}`);
    }
}

@NgModule({
    imports:      [ BrowserModule,  ReactiveFormsModule],
    declarations: [ ObserverComponent],
    bootstrap:    [ ObserverComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);


*/
