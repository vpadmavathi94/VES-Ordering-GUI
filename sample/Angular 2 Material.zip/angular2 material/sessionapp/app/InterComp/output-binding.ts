import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, Component, Output, EventEmitter } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

interface IPriceQuote {
    stockSymbol: string;
    lastPrice: number;
}

@Component({
    selector: 'price-quoter',
    template: `<h1 class="well text-danger">
                Child PriceQuoterComponent:
               {{stockSymbol}} 
                      {{price | currency:'USD':'1.2'}}
               </h1>
               `
})
class PriceQuoterComponent {

    @Output() lastPrice: EventEmitter <IPriceQuote> =
                         new EventEmitter();
    stockSymbol: string = "Verizon";
    price:number;

    constructor() {
        setInterval(() => {
            let priceQuote: IPriceQuote = {
                stockSymbol: this.stockSymbol,
                lastPrice: 100*Math.random()
            };
            this.price = priceQuote.lastPrice;
            this.lastPrice.emit(priceQuote);//Raise Event
        }, 1000);
    }
}
@Component({
    selector: 'my-app',
    template: `
    <div class='container'>
        <h1 class='text-success'>
        Parent Component received: 
        {{stockSymbol}} {{price | currency:'USD':true:'1.2'}}
        </h1>

   <price-quoter  (lastPrice)="priceQuoteHandler($event)">
   </price-quoter>    
    </div>
    `,
   })
class OutputComponent {

    stockSymbol: string;
    price:number;

    priceQuoteHandler(event:IPriceQuote) {
        this.stockSymbol = event.stockSymbol;
        this.price = event.lastPrice;
    }
}
@NgModule({
    imports:      [ BrowserModule],
    declarations: [ OutputComponent, PriceQuoterComponent],
    bootstrap:    [ OutputComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);