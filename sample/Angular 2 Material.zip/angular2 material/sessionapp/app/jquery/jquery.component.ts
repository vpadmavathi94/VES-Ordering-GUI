import {Component, ElementRef, Inject, OnInit} from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule }      from '@angular/core';
import { BrowserModule } from  '@angular/platform-browser';
declare var jQuery:any;

@Component({
    selector: 'my-app',
    template:` 
   <div class='container'>
	<h1>Integrating jQuery with Angular 2.0</h1>

	<div class="info">Observe here</div>
	</div>
    `
})
export class JqueryIntegration implements OnInit {
    elementRef: ElementRef;
    constructor(@Inject(ElementRef) elementRef: ElementRef) {
        this.elementRef = elementRef;
    }
    ngOnInit() {
        jQuery(this.elementRef.nativeElement)
        .find('.info')
        .html("<h1 class='text-danger'>I am dynamic content</h1>")
        .fadeIn(2000)
        .fadeOut(1000)
        .fadeIn(2000)
        .css('background-color','orange')

    };
}

@NgModule({
    imports:      [ BrowserModule],
    declarations: [ JqueryIntegration],
    bootstrap:    [ JqueryIntegration ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);