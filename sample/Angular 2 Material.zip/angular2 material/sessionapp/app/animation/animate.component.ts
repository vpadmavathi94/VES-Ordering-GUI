
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, Component, Input }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import {trigger,state,style,transition,animate,keyframes } from '@angular/core';


@Component({
    selector: 'my-app',
    template: `
    <div class="container">
     <div class="row" >
        <div class="columns">
            <button (click)="toggleMove()">Press me for animation</button>
        </div>
        <h2 class="columns">
            <div id="content" [@focusPanel]='state' [@movePanel]='state'>Murthy Infotek</div>
        </h2>
      </div>
   </div>
    `,
    styles: [`
        button { font-size:1.8em; }
        #content { padding:30px; background:#eeeeee; }
    `],
    animations: [

        trigger('focusPanel', [
            state('inactive', style({
                transform: 'scale(1)',
                backgroundColor: '#33aacc'
            })),
            state('active', style({
                transform: 'scale(1.2)',
                backgroundColor: '#33ccaa'
            })),
            transition('inactive => active', animate('100ms ease-in')),
            transition('active => inactive', animate('100ms ease-out'))
        ]),

        trigger('movePanel', [
            
            transition('void => *', [
                animate(600, keyframes([
                    style({opacity: 0, transform: 'translateY(-200px)', offset: 0}),
                    style({opacity: 1, transform: 'translateY(25px)', offset: .75}),
                    style({opacity: 1, transform: 'translateY(0)', offset: 1}),
                ]))
            ])

        ])


    ]


})
export class AnimateComponent {
    state: string = 'inactive';

    toggleMove() {
        this.state = (this.state === 'inactive' ? 'active' : 'inactive');
    }

}
    
@NgModule({
    imports:      [ BrowserModule],
    declarations: [ AnimateComponent],
    bootstrap:    [ AnimateComponent]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);