export class Bid{
     id: number;
     productID: number;
     amount: number;
     userID: number;
     bidTime: Date;

}
