import { Component } from '@angular/core';

@Component({
  selector: 'my-about',
  template: `
    <h2>About Component</h2>
    <p>This is the about component</p>
  `,
})
export class About {}
