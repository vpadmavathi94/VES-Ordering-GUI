import { Component } from '@angular/core';
import { Home } from './home';
import { About } from './about';

@Component({
  selector: 'my-app',
  template: `
  
    <h1 style='background-color:yellow'>Angular2 with Webpack by Murthy</h1>
    <h3 style="background-color:grey;color:white">
      <a [routerLink]="['/']">Home</a>
      <a [routerLink]="['/about']">About</a>
    </h3>

    <div style='background-color:lightgreen'>
      <router-outlet></router-outlet>
    </div>
  `
})
export class MyApp {}
