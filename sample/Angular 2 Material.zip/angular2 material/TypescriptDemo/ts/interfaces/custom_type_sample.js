/*
interface IPerson {

    firstName: string;
    lastName: string;
    age: number;
    ssn?: string;
}

class Person  {

    constructor(public config: IPerson) {
    }
}

var aPerson: IPerson = {
    firstName: "John",
    lastName: "Smith",
    age: 29,
    department: "aaa"
}

var p = new Person(aPerson);
console.log("Last name: " + p.config.lastName);

*/
//# sourceMappingURL=custom_type_sample.js.map