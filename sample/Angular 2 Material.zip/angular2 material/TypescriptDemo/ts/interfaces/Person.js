var Person = (function () {
    function Person(config) {
        this.config = config;
    }
    return Person;
})();
//# sourceMappingURL=Person.js.map