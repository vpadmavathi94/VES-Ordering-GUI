
interface IPerson {

    firstName: string;
    lastName: string;
    age: number;
    ssn: string;
}