class Person  {

    constructor(public config: IPerson) {
        config.firstName = "sriram";


    }
}