function StockQuoteGeneratorArrow(symbol: string){

    this.symbol = symbol; 

    setInterval(() => { 
        console.log("StockQuoteGeneratorArrow. The price quote for " + this.symbol
            + " is " + Math.random());
    }, 1000);

}

var stockQuoteGeneratorArrow = new StockQuoteGeneratorArrow("Verizon");


function StockQuoteGeneratorAnonymous(symbol: string){

    this.symbol = symbol; 

    setInterval(function () {  
        console.log("   StockQuoteGeneratorAnonymous.The price quote for " + this.symbol
            + " is " + Math.random());
    }, 1000);

}

var stockQuoteGeneratorAnonymous = new StockQuoteGeneratorAnonymous("IBM");