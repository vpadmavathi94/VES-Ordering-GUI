// Assignment of different types
var dynamic:any = 'A string';

// Cannot convert 'number' to 'string'.
//dynamic = 52;




// Calling functions
function getVolume(width, height, depth) {
    return width * height * depth;
}

// NaN (10 * undefined * undefined)
// Supplied arguments do match any signature of call target.
//var volumeA = getVolume(10);

// 32 (the 8 is ignored)
// Supplied arguments do match any signature of call target.
var volumeB = getVolume(2, 4, 4,9);
 