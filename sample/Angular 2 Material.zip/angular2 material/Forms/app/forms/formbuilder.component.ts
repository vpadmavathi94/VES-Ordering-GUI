import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ReactiveFormsModule, FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'my-app',
  template: `
  <h2 class="text-danger">Form Builder </h2>
    <form [formGroup]="formModel" (ngSubmit)="onSubmit()">
      <table border="1" style="margin:20px">
      <caption>Fill the User Details</caption>
      <tr>
      <td>Username: <input type="text" formControlName="username"></td>
      </tr>
      <tr>
      <td>SSN Code:      <input type="text" formControlName="ssn"></td>
      </tr>
      <tr>
      <div formGroupName="passwordsGroup">
        <td>Password:        <input type="password" 
               formControlName="password"></td>
        <td>Confirm password: <input type="password" 
             formControlName="pconfirm"></td>
      </div>
      </tr>
      
      <button type="submit" class='btn-success'>Submit</button>
      </table>
    </form>
  `
})
class FormBuilderComponent {
  formModel: FormGroup;

  constructor(fb: FormBuilder) {
    this.formModel = fb.group({
      'username': [''],
      'ssn': [''],
      'passwordsGroup': fb.group({
        'password': [''],
        'pconfirm': ['']
      })
    });
  }

  onSubmit() {
    console.log(this.formModel.value);
  }
}

@NgModule({
  imports     : [ BrowserModule, ReactiveFormsModule ],
  declarations: [ FormBuilderComponent],
  bootstrap   : [ FormBuilderComponent]
})
class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule);
