import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'my-app',
  template: `
    <h2 class="text-success">Template Binding </h2>
    <form  #f="ngForm" (ngSubmit)="onSubmit(f.value)">
      <label for="username">Username</label>
         <input type="text" name="username" ngModel><br/>
      <label for="ssn">SSC</label>
         <input type="text" name="ssn" ngModel><br/>

      <label for="password">Password</label>
        <input type="password" name="password" ngModel><br/>
      <label for="pconfirm">Confirm Password</label>
        <input type="password" name="pconfirm"  ngModel>

      <button type="submit" class="btn-primary">Submit</button>
    </form>
 `
  
})
export class TemplateComponent {
  onSubmit(formData:any) {
    console.log(formData);
  }
}

@NgModule({
  imports     : [ BrowserModule, FormsModule ],
  declarations: [ TemplateComponent ],
  bootstrap   : [ TemplateComponent ]
})
export class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule);
