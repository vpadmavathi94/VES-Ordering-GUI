import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';

/**
 * Returns `true` if FormControl's value represents a valid SSN,
 * otherwise returns `false`.
 */
function ssnValidator(control: FormControl): {[key: string]: any} {
  const value: string = control.value || '';
  const valid = value.match(/^\d{9}$/);
  return valid ? null : {ssn: {description: 'Sorry...SSN is invald'}};
}

@Component({
  selector: 'my-app',
  template: `
  <h2 class="text-success">Custom Validator with error Message</h2>
    <form [formGroup]="form">
      SSN: <input type="text" formControlName="my-ssn">
           <span class="text-danger" [hidden]="!form.hasError('ssn', 'my-ssn')">
             {{form.getError('ssn', 'my-ssn')?.description}}
           </span>
    </form>
  `
})
class ErrorMessageComponent {
  form: FormGroup;

  constructor() {
    this.form = new FormGroup({
      'my-ssn': new FormControl('', ssnValidator)
    });
  }
}

@NgModule({
  imports     : [ BrowserModule, ReactiveFormsModule ],
  declarations: [ ErrorMessageComponent ],
  bootstrap   : [ ErrorMessageComponent]
})
class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule);
