import { Routes, RouterModule } from '@angular/router';
import {ContactListComponent} from "./components/contactlist.component";
import {NewContactComponent} from "./components/newcontact.component";
import {ShowComponent} from "./components/show.component";
const routes: Routes = [
    {path: '',component: ContactListComponent},
    {path: 'newcontact', component: NewContactComponent},
    {path:'show/:name',component:ShowComponent}
];

export const routing = RouterModule.forRoot(routes);