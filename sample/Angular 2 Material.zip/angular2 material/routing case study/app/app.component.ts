import { Component } from '@angular/core';

import {ContactListComponent} from './components/contactlist.component';


@Component({
    selector: 'my-app',
    template: `<h2>Routing Demo by Murthy</h2>
    <nav>
        <a [routerLink]="['/']" >Home</a>
        <a [routerLink]="['/newcontact']" >Add new Contact</a>
        <a [routerLink]="['/show','Murthy']">Show contact</a>        
    </nav>
        <div class="well">
        	<router-outlet></router-outlet>
        </div>

    `   

})
export class AppComponent { }
