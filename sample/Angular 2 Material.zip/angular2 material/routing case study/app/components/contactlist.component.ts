import {Component} from '@angular/core';
import {OnInit} from '@angular/core';  



import {Contact} from './contact';
import {ContactService} from './contact.service';

@Component({
  selector: 'contact-list',    
    providers:[ContactService],
    template: ` 
  Contacts List:
  <table border="2">
  <div *ngFor="let contact of contacts" 
       (click)="selectedContact(contact)" >
           
     <span style="margin:20px"  [class.clicked]="showDetails" >      
    <tr>
        <td> {{contact.name}} - &nbsp;  
              {{contact.email}} - &nbsp;
              {{contact.phone}} 
        </td>
     </tr>     
     </span>
  </div>
  </table>
  <br/>
  <div style="background-color:yellow">
    <h3>Working with Angular 2 Routing</h3>
    </div>
    `
    
    //stylesUrl:["./src/app.css"]
})

export class ContactListComponent implements OnInit{
	// it is not advisable to invoke data in constructor (heavy data)
	// solution is use comp. life cycle hooks (ngInit)
/*	
  public contacts=[
  {name:'xxxSriram',email:'murthy@yahoo.com',phone:2393993},
  {name:'Raju',email:'Raju@gmail.com',phone:4543993},
  {name:'Lalitha',email:'lalitha@yahoo.com',phone:543454},
  {name:'Kavitha',email:'kavitha@yahoo.com',phone:454493}
  ]
  */

  public contacts:Contact[];
  public selected={};
  public showDetails:boolean=false;

  constructor(private _contactService:ContactService){
  	console.log("Service is injected")
  }


  getContacts(){
  	console.log("In getContacts method");
  	this._contactService.getContacts().then(cnts=>this.contacts=cnts)
  }
 
   ngOnInit(){
   	console.log("ngOnInit fired and contacts injected");
   	this.getContacts();// invoke method here
   }


/*
  constructor() {
    console.log("Contact component is initialized");
  }
  */
  selectedContact(contact:Contact){
  	this.selected=contact;
  	this.showDetails=true;
  	//this.selected={email:contact.email,phone:contact.phone};
  }
}