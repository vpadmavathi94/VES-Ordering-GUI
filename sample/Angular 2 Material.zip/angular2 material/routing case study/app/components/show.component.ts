import {Component} from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'show',
  template: `<h1 class="mycolor">Contact Detail: {{name}}</h1>`,
  styles: ['.mycolor {background: cyan}']
})
export class ShowComponent{
  name: string;

  constructor(private route: ActivatedRoute) {
   this.name = route.snapshot.params['name'];


    // Subscribing for receiving changing params
   /*this.route.params.subscribe(
        params => this.name = params['name']
    );*/

  }
}