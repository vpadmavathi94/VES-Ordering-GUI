import {Component} from '@angular/core';
import {Contact} from './contact';
import {ContactService} from './contact.service';

import { Router, Routes, RouterModule } from '@angular/router';

@Component({
  selector: 'new-contact',
  template: ` 
    <div style='background-color:orange'>Add New  Contact:
     <div>
     	<label for="name">Name </label>
      	<input type="text" id="name" #cname>
     </div>
      <div>
     	<label for="email">Email ID </label>
      	<input type="email" id="mail" #mail >
      </div>
   	<div>
   		<label for="phone" >Phone</label>
         <input type="text" id='phone' #ph >  
      </div>
      <input type="submit" value="Add new Contact" 
        (click)="onInsert(cname.value,mail.value,ph.value)"
         class="btn-primary">
     </div>
    `,
    providers:[ContactService],
    styles:[
    `
    	label{ display:inline-block;width:100px}
    	input{width:200px}
    `
    ]
})
export class NewContactComponent{
public contact={};  
constructor(
      private  _contactService:ContactService,
      private _router: Router){
  //inject the service
}
onInsert(cname:string,mail:string,ph:string){
  let newcontact:Contact={name:cname,email:mail,phone:ph}
  this._contactService.insertContact(newcontact);
  console.log("new Contact is added to Contacts List");
  this._router.navigate(["/"]);
}

}
