System.register(['angular2/core', "../Mock/discounts.mock.json"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, discounts_mock_json_1;
    var CartService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (discounts_mock_json_1_1) {
                discounts_mock_json_1 = discounts_mock_json_1_1;
            }],
        execute: function() {
            CartService = (function () {
                function CartService() {
                    this.cart = [];
                }
                CartService.prototype.addItem = function (item) {
                    this.cart.push(item);
                };
                CartService.prototype.deleteItem = function (item) {
                    this.cart = this.cart.filter(function (cartItem) { return cartItem.id !== item.id; });
                };
                CartService.prototype.clearCart = function () {
                    this.cart = [];
                };
                CartService.prototype.applyDiscount = function (code) {
                    this.discount = discounts_mock_json_1.discounts.filter(function (discount) { return discount.code == code; })[0];
                };
                CartService.prototype.getCart = function () {
                    return this.cart;
                };
                CartService.prototype.getTotalPrice = function () {
                    var totalPrice = this.cart.reduce(function (sum, cartItem) {
                        return sum += cartItem.price, sum;
                    }, 0);
                    if (this.discount) {
                        totalPrice -= totalPrice = this.discount.amount;
                    }
                    return totalPrice;
                };
                CartService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], CartService);
                return CartService;
            }());
            exports_1("CartService", CartService);
        }
    }
});
//# sourceMappingURL=cart.service.js.map