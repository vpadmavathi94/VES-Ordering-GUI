System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var DefaultCheckout;
    return {
        setters:[],
        execute: function() {
            DefaultCheckout = (function () {
                function DefaultCheckout() {
                    this._checkOutType = null;
                }
                Object.defineProperty(DefaultCheckout.prototype, "checkOutType", {
                    set: function (value) {
                        this._checkOutType = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                DefaultCheckout.prototype.checkOut = function (totalPrice) {
                    return this._checkOutType ? this._checkOutType.pay(totalPrice) : "Please select method of payment";
                };
                return DefaultCheckout;
            }());
            exports_1("DefaultCheckout", DefaultCheckout);
        }
    }
});
//# sourceMappingURL=checkout.service.js.map