System.register(['angular2/core', "angular2/common", './Services/shopping.service', "./item-preview.component", './Utils/Filter.pipe'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, shopping_service_1, item_preview_component_1, Filter_pipe_1;
    var Catalog;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (shopping_service_1_1) {
                shopping_service_1 = shopping_service_1_1;
            },
            function (item_preview_component_1_1) {
                item_preview_component_1 = item_preview_component_1_1;
            },
            function (Filter_pipe_1_1) {
                Filter_pipe_1 = Filter_pipe_1_1;
            }],
        execute: function() {
            Catalog = (function () {
                function Catalog(catalogService) {
                    this.catalogService = catalogService;
                    this.catalog = [];
                    this.search = "";
                }
                Catalog.prototype.ngOnInit = function () {
                    var _this = this;
                    this.catalogService.getCatalog().then(function (catalog) {
                        _this.catalog = catalog;
                    });
                };
                Catalog = __decorate([
                    core_1.Component({
                        selector: 'catalog',
                        pipes: [Filter_pipe_1.FilterCatalogItems],
                        directives: [item_preview_component_1.ItemPreview, common_1.FORM_DIRECTIVES, common_1.NgIf],
                        template: "\n        <h2 class=\"text-danger\" style=\"background-color:lightgreen\">Catalog- Enjoy shopping</h2>\n        <div class=\"container\" *ngIf=catalog>\n            <div class=\"row\">\n                <div class=\"col-md-4\">\n                    Search:<br/>\n                    <input type=\"text\" [(ngModel)]=\"search\"/>\n                </div>\n                <div class=\"col-md-8\">\n                    <item-preview *ngFor=\"#item of catalog | filterItems:search\" [item]=\"item\"></item-preview>\n                </div>\n            </div>\n        </div>\n    ",
                    }), 
                    __metadata('design:paramtypes', [shopping_service_1.CatalogService])
                ], Catalog);
                return Catalog;
            }());
            exports_1("Catalog", Catalog);
        }
    }
});
//# sourceMappingURL=catalog.component.js.map