System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var PayPalCheckout, MasterCard, Visa;
    return {
        setters:[],
        execute: function() {
            PayPalCheckout = (function () {
                function PayPalCheckout() {
                    this.name = "PayPal";
                }
                PayPalCheckout.prototype.pay = function (totalPrice) {
                    return "PayPal: pay stage 1 with amount " + totalPrice + "\n        PayPal: pay stage 2\n        PayPal: payed";
                };
                return PayPalCheckout;
            }());
            exports_1("PayPalCheckout", PayPalCheckout);
            MasterCard = (function () {
                function MasterCard() {
                    this.name = "MasterCard";
                }
                MasterCard.prototype.pay = function (totalPrice) {
                    return "MasterCard: pay stage 1 with amount " + totalPrice + "\n        MasterCard: pay stage 2\n        MasterCard: payed";
                };
                return MasterCard;
            }());
            exports_1("MasterCard", MasterCard);
            Visa = (function () {
                function Visa() {
                    this.name = "Visa";
                }
                Visa.prototype.pay = function (totalPrice) {
                    return "Visa: pay stage 1 with amount " + totalPrice + "\n        Visa: pay stage 2\n        Visa: payed";
                };
                return Visa;
            }());
            exports_1("Visa", Visa);
        }
    }
});
//# sourceMappingURL=payment-methods.js.map