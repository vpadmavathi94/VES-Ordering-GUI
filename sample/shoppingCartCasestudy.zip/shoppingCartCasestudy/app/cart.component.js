System.register(['angular2/core', "angular2/common", "./Services/cart.service", "./item-preview.component", "./Services/checkout.service", "./Mock/payment-methods.mock.json"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, cart_service_1, item_preview_component_1, checkout_service_1, payment_methods_mock_json_1;
    var Cart;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (cart_service_1_1) {
                cart_service_1 = cart_service_1_1;
            },
            function (item_preview_component_1_1) {
                item_preview_component_1 = item_preview_component_1_1;
            },
            function (checkout_service_1_1) {
                checkout_service_1 = checkout_service_1_1;
            },
            function (payment_methods_mock_json_1_1) {
                payment_methods_mock_json_1 = payment_methods_mock_json_1_1;
            }],
        execute: function() {
            Cart = (function () {
                function Cart(cartService, defaultCheckout) {
                    this.cartService = cartService;
                    this.defaultCheckout = defaultCheckout;
                    this.cartItems = [];
                    this.paymentOutput = "";
                    this.cartItems = cartService.getCart();
                }
                Cart.prototype.setPaymentType = function (type) {
                    this.defaultCheckout.checkOutType =
                        payment_methods_mock_json_1.paymentMethods.filter(function (paymentMethod) {
                            return paymentMethod.name.toLowerCase() === type.toLowerCase();
                        })[0];
                };
                Cart.prototype.setDiscount = function (name) {
                    this.cartService.applyDiscount(name);
                };
                Cart.prototype.pay = function () {
                    this.paymentOutput = this.defaultCheckout.checkOut(this.cartService.getTotalPrice());
                };
                Cart = __decorate([
                    core_1.Component({
                        selector: 'cart',
                        directives: [common_1.NgIf, item_preview_component_1.ItemPreview, common_1.FORM_DIRECTIVES],
                        providers: [checkout_service_1.DefaultCheckout],
                        template: "\n        <h2 class='text-danger well'>Shopping Cart </h2>\n        <div *ngIf=cartItems>\n            <div class=\"container\">\n                <div class=\"row\" *ngFor=\"#item of cartItems\">\n                    <item-preview [item]=\"item\"></item-preview>\n                </div>\n            </div>\n            <div class=\"container\">\n                <div class=\"row\">\n                    <input type=\"text\" #input/>\n                    <button (click)=\"setDiscount(input.value)\" class=\"btn btn-info\">Apply discount</button>\n                </div>\n            </div>\n            <div class=\"container\">\n                <div class=\"row\">\n                    Total pay: {{cartService.getTotalPrice()}}\n                </div>\n            </div>\n            <div class=\"container\">\n                <div class=\"row\" (click)=\"setPaymentType($event.target.value)\">\n                    Please select payment method:\n                    <button value=\"PayPal\" class=\"btn btn-primary\">PayPal</button>\n                    <button value=\"Visa\" class=\"btn btn-primary\">Visa</button>\n                    <button value=\"MasterCard\" class=\"btn btn-primary\">MasterCard</button>\n                </div>\n            </div>\n            <div class=\"container\">\n                <div class=\"row\">\n                    <button (click)=\"pay()\" class=\"btn btn-danger\">Make Payment </button>\n                </div>\n            </div>\n            <div class=\"container\" *ngIf=\"paymentOutput\">\n                <h3 class=\"row\" style=\"background-color:orange\">\n                    {{paymentOutput}}\n                </h3>\n            </div>\n        </div>\n    ",
                    }), 
                    __metadata('design:paramtypes', [cart_service_1.CartService, checkout_service_1.DefaultCheckout])
                ], Cart);
                return Cart;
            }());
            exports_1("Cart", Cart);
        }
    }
});
//# sourceMappingURL=cart.component.js.map