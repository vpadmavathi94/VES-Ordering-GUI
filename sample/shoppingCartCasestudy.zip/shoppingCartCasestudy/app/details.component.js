System.register(['angular2/core', "angular2/common", 'angular2/router', './Services/shopping.service', "./Services/cart.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, router_1, shopping_service_1, cart_service_1;
    var Details;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (shopping_service_1_1) {
                shopping_service_1 = shopping_service_1_1;
            },
            function (cart_service_1_1) {
                cart_service_1 = cart_service_1_1;
            }],
        execute: function() {
            Details = (function () {
                function Details(routeParams, catalogService, cartService) {
                    this.routeParams = routeParams;
                    this.catalogService = catalogService;
                    this.cartService = cartService;
                    this.loadDetailsById(routeParams.get("id"));
                }
                Details.prototype.loadDetailsById = function (id) {
                    this.details = this.catalogService.getById(id);
                };
                Details = __decorate([
                    core_1.Component({
                        selector: 'item-details',
                        directives: [common_1.NgIf, common_1.NgFor],
                        template: "\n    <div class=\"container\">\n        <div class=\"row\" *ngIf=details>\n            <div class=\"col-md-4\"><img src={{details.image_src}}/></div>\n            <div class=\"col-md-4\">{{details.name}}<br/>{{details.manufacturer}}<br/>{{details.price}}<br/>{{details.averageReviewRate}}</div>\n        </div>\n        <div class=\"row\" *ngIf=details.comments>\n            <h3>Comments</h3>\n            <div class=\"row\" *ngFor=\"#comment of details.comments\">\n               <div class=\"col-md-4\"><img src={{comment.name}}/></div>\n               <div class=\"col-md-4\" *ngIf=\"comment.rate\"><img src={{comment.rate}}/></div>\n               <div class=\"col-md-4\">{{comment.comment}}</div>\n            </div>\n        </div>\n        <div class=\"row\" *ngIf=!details>\n            <h3>Loading</h3>\n        </div>\n    </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [router_1.RouteParams, shopping_service_1.CatalogService, cart_service_1.CartService])
                ], Details);
                return Details;
            }());
            exports_1("Details", Details);
        }
    }
});
//# sourceMappingURL=details.component.js.map