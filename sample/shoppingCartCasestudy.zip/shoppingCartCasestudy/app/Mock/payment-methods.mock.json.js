System.register(['../Utils/payment-methods'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var payment_methods_1;
    var paymentMethods;
    return {
        setters:[
            function (payment_methods_1_1) {
                payment_methods_1 = payment_methods_1_1;
            }],
        execute: function() {
            exports_1("paymentMethods", paymentMethods = [new payment_methods_1.Visa(), new payment_methods_1.MasterCard(), new payment_methods_1.PayPalCheckout()]);
        }
    }
});
//# sourceMappingURL=payment-methods.mock.json.js.map