System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var discounts;
    return {
        setters:[],
        execute: function() {
            exports_1("discounts", discounts = [{
                    code: "10",
                    amount: 10
                }, {
                    code: "20",
                    amount: 20
                }]);
        }
    }
});
//# sourceMappingURL=discounts.mock.json.js.map