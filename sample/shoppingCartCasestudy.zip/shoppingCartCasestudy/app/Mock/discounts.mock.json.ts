export var discounts = [{
   code:"10",
    amount:10
},{
    code:"20",
    amount:20
}];